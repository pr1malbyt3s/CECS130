/*
$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
Code Name: problem_2.c
Author: Aaron Williams
Class: CECS 130-50
Version: 1.0
Description: Prints the directory structure c:\cygwin\home\administrator
$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
*/

#include <stdio.h>

int main(void) {
	printf("c:\\cygwin\\home\\administrator\n");
	
	return 0;
}