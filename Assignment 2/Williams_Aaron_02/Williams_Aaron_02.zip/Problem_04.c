/*
$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
Code Name: problem_04.c
Author: Aaron Williams
Class: CECS 130-50
Assignment 2
Version: 1.0
Description: This code produces no output. It is simply a source code file that
provides prototypes for three functions.
$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
*/

//Function prototype for the following:

//A function that divides two numbers and returns the remainder.
int remain(int, int);

//A function that finds the larger of two numbers and returns the result.
double greater(double, double);

//A function that prints an ATM menu- it receives no parameters and returns no value.
void ATM(void);
